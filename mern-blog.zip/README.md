# 📝 MERN Blog

A simple full-stack blog app built with **MongoDB**, **Express**, **React**, and **Node.js (MERN)**.  
You can create, view, and manage blog posts with categories — connected to a MongoDB Atlas cloud database.

---

## 🚀 Features

- Create and view blog posts  
- Manage categories  
- RESTful API built with Express & MongoDB  
- React frontend with Vite  
- Environment variable support (.env)  
- Fully connected to MongoDB Atlas  

---

## 🧩 Tech Stack

| Layer | Technology |
|--------|-------------|
| **Frontend** | React + Vite |
| **Backend** | Node.js + Express |
| **Database** | MongoDB Atlas |
| **State Management** | React Context API |
| **HTTP Client** | Axios |
| **Styling** | Basic CSS |

---

## 🛠️ Project Structure
mern-blog/
├── client/                #        React frontend
├── src/ │
  ├── pages/         # Home,        -CreatePost pages │   
  ├── components/    # Navbar, etc.  
  ├── context/       # React Context for posts   
  ├── services/      # Axios API calls    
  ├── App.jsx 
  └── main.jsx
 ├── package.json
  └── .env
  
  ├── server/           
   Express backend
     ├── config/            # Database connection 
     ├── controllers/       # Logic for posts & categories 
     ├── models/            # Mongoose models  
     ├── routes/            # API routes 
     ├── middleware/        # Custom error handler
     ├── server.js          # Entry point 
     ├── package.json
     └── .env
     └── README.md
     
 
## ⚙️ Setup Instructions

### 1️⃣ Clone the Repository
```bash
git clone https://github.com/<your-username>/mern-blog.git
cd mern-blog

2️⃣ Install Backend Dependencies

cd server
npm install

Create a .env file inside server/ and add:

MONGO_URI=your_mongodb_atlas_connection_string
PORT=5000
NODE_ENV=development


3️⃣ Run the Backend Server

npm run dev

The API will start at http://localhost:5000


4️⃣ Install Frontend Dependencies

Open a new terminal:

cd ../client
npm install

Create a .env file inside client/:

VITE_API_URL=http://localhost:5000/api


5️⃣ Run the Frontend (React)

npm run dev

The frontend will be available at something like:

http://localhost:5173

If you’re using Termux or testing on another device, replace localhost with your device IP in client/.env.


🧪 API Endpoints

Method	Endpoint	Description

GET	/api/posts	Get all posts
POST	/api/posts	Create a new post
GET	/api/posts/:id	Get single post
PUT	/api/posts/:id	Update post
DELETE	/api/posts/:id	Delete post
GET	/api/categories	Get all categories
POST	/api/categories	Create a category


🧠 Environment Variables

Variable	Description

MONGO_URI	MongoDB Atlas connection string
PORT	Backend server port
NODE_ENV	Environment mode
VITE_API_URL	Frontend API base URL


🪄 Example Workflow

1. Start backend: cd server && npm run dev


2. Start frontend: cd client && npm run dev


3. Go to browser → http://localhost:5173


4. Create a new post → it’ll appear immediately


5. Data saved in your MongoDB Atlas collection

Screenshots 
 Screenshots are available in the image folders 


🧰 Tools Used

MongoDB Atlas
Express
React
Node.js
Axios
Vite

💻 Author

Prudence Sehahabane
💬 MERN Stack Developer in progress 🌱
📧 Contact: [prudencesehahabane@gmail.com]
