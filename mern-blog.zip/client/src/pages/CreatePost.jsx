import { useState, useContext } from "react";
import { createPost } from "../services/api.js";
import { PostContext } from "../context/PostContext.jsx";

export default function CreatePost() {
  const { setPosts } = useContext(PostContext);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    try {
      const res = await createPost({ title, content });
      setPosts(prev => [res.data, ...prev]);
      setTitle(""); setContent("");
      alert("Post created");
    } catch (err) {
      console.error(err);
      alert("Create failed");
    }
  };

  return (
    <div className="container">
      <h1>Create Post</h1>
      <form onSubmit={submit}>
        <div>
          <label>Title</label>
          <input value={title} onChange={e=>setTitle(e.target.value)} required />
        </div>
        <div>
          <label>Content</label>
          <textarea value={content} onChange={e=>setContent(e.target.value)} required />
        </div>
        <button type="submit">Create</button>
      </form>
    </div>
  );
}