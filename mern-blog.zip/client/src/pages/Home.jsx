import { useContext } from "react";
import { PostContext } from "../context/PostContext.jsx";

export default function Home() {
  const { posts } = useContext(PostContext);

  return (
    <div className="container">
      <h1>All Posts</h1>
      {posts.length === 0 ? (
        <p>No posts yet.</p>
      ) : (
        posts.map(post => (
          <div key={post._id} className="card">
            <h3>{post.title}</h3>
            <p>{post.content}</p>
          </div>
        ))
      )}
    </div>
  );
}