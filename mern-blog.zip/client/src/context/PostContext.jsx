import { createContext, useState, useEffect } from "react";
import { getPosts, getCategories } from "../services/api.js";

export const PostContext = createContext();

export const PostProvider = ({ children }) => {
  const [posts, setPosts] = useState([]);
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        const p = await getPosts();
        setPosts(p.data);
      } catch (e) {
        console.error("Failed to fetch posts", e);
        setPosts([]);
      }
      try {
        const c = await getCategories();
        setCategories(c.data);
      } catch (e) {
        setCategories([]);
      }
    })();
  }, []);

  return (
    <PostContext.Provider value={{ posts, setPosts, categories, setCategories }}>
      {children}
    </PostContext.Provider>
  );
};